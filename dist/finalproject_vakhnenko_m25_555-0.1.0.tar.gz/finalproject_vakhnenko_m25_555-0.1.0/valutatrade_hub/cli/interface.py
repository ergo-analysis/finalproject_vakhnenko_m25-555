import argparse
import sys
import getpass
from typing import Optional

from ..core.usecases import UserManager, PortfolioManager


class SessionManager:
    _current_user_id: Optional[int] = None
    _current_username: Optional[str] = None
    
    @classmethod
    def login(cls, user_id: int, username: str):
        cls._current_user_id = user_id
        cls._current_username = username
    
    @classmethod
    def logout(cls):
        cls._current_user_id = None
        cls._current_username = None
    
    @classmethod
    def is_logged_in(cls) -> bool:
        return cls._current_user_id is not None
    
    @classmethod
    def get_current_user_id(cls) -> Optional[int]:
        return cls._current_user_id
    
    @classmethod
    def get_current_username(cls) -> Optional[str]:
        return cls._current_username


def register_command(args):
    try:
        result = UserManager.register(args.username, args.password)
        print(result)
    except ValueError as e:
        print(f"Ошибка: {e}")
        sys.exit(1)


def login_command(args):
    try:
        user_id, message = UserManager.login(args.username, args.password)
        SessionManager.login(user_id, args.username)
        print(message)
    except ValueError as e:
        print(f"Ошибка: {e}")
        sys.exit(1)


def show_portfolio_command(args):
    if not SessionManager.is_logged_in():
        print("Ошибка: Сначала выполните login")
        sys.exit(1)
    
    try:
        portfolio_info = PortfolioManager.get_portfolio_info(
            SessionManager.get_current_user_id(),
            args.base
        )
        
        print(f"Портфель пользователя '{SessionManager.get_current_username()}' (база: {portfolio_info['base_currency']}):")
        
        if not portfolio_info["wallets"]:
            print("  У вас пока нет кошельков")
            return
        
        for wallet in portfolio_info["wallets"]:
            print(f"  - {wallet['currency']}: {wallet['balance']:.4f} → {wallet['value_in_base']:.2f} {portfolio_info['base_currency']}")
        
        print(f"  {'-' * 40}")
        print(f"  ИТОГО: {portfolio_info['total_value']:,.2f} {portfolio_info['base_currency']}")
    
    except Exception as e:
        print(f"Ошибка: {e}")
        sys.exit(1)


def buy_command(args):
    if not SessionManager.is_logged_in():
        print("Ошибка: Сначала выполните login")
        sys.exit(1)
    
    try:
        result = PortfolioManager.buy_currency(
            SessionManager.get_current_user_id(),
            args.currency.upper(),
            args.amount
        )
        print(result)
    except ValueError as e:
        print(f"Ошибка: {e}")
        sys.exit(1)


def sell_command(args):
    if not SessionManager.is_logged_in():
        print("Ошибка: Сначала выполните login")
        sys.exit(1)
    
    try:
        result = PortfolioManager.sell_currency(
            SessionManager.get_current_user_id(),
            args.currency.upper(),
            args.amount
        )
        print(result)
    except ValueError as e:
        print(f"Ошибка: {e}")
        sys.exit(1)


def get_rate_command(args):
    try:
        rate_info = PortfolioManager.get_exchange_rate(args.from_currency, args.to_currency)
        
        print(f"Курс {rate_info['from_currency']}→{rate_info['to_currency']}: {rate_info['rate']:.8f}")
        print(f"Время обновления: {rate_info['updated_at']}")
        print(f"Источник: {rate_info['source']}")
        print(f"Обратный курс {rate_info['to_currency']}→{rate_info['from_currency']}: {rate_info['inverse_rate']:.8f}")
    
    except ValueError as e:
        print(f"Ошибка: {e}")
        sys.exit(1)


def logout_command(args):
    if SessionManager.is_logged_in():
        username = SessionManager.get_current_username()
        SessionManager.logout()
        print(f"Вы вышли из системы. До свидания, {username}!")
    else:
        print("Вы не были в системе")


def create_parser():
    parser = argparse.ArgumentParser(
        description="ValutaTrade Hub - Симулятор торговли валютой",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Доступные команды")
    
    # Регистрация
    register_parser = subparsers.add_parser("register", help="Зарегистрировать нового пользователя")
    register_parser.add_argument("--username", required=True, help="Имя пользователя")
    register_parser.add_argument("--password", required=True, help="Пароль")
    register_parser.set_defaults(func=register_command)
    
    # Вход
    login_parser = subparsers.add_parser("login", help="Войти в систему")
    login_parser.add_argument("--username", required=True, help="Имя пользователя")
    login_parser.add_argument("--password", required=True, help="Пароль")
    login_parser.set_defaults(func=login_command)
    
    # Выход
    logout_parser = subparsers.add_parser("logout", help="Выйти из системы")
    logout_parser.set_defaults(func=logout_command)
    
    # Портфель
    portfolio_parser = subparsers.add_parser("show-portfolio", help="Показать портфель")
    portfolio_parser.add_argument("--base", default="USD", help="Базовая валюта (по умолчанию: USD)")
    portfolio_parser.set_defaults(func=show_portfolio_command)
    
    # Покупка
    buy_parser = subparsers.add_parser("buy", help="Купить валюту")
    buy_parser.add_argument("--currency", required=True, help="Код покупаемой валюты (например, BTC)")
    buy_parser.add_argument("--amount", type=float, required=True, help="Количество покупаемой валюты")
    buy_parser.set_defaults(func=buy_command)
    
    # Продажа
    sell_parser = subparsers.add_parser("sell", help="Продать валюту")
    sell_parser.add_argument("--currency", required=True, help="Код продаваемой валюты")
    sell_parser.add_argument("--amount", type=float, required=True, help="Количество продаваемой валюты")
    sell_parser.set_defaults(func=sell_command)
    
    # Курс валюты
    rate_parser = subparsers.add_parser("get-rate", help="Получить курс валюты")
    rate_parser.add_argument("--from", dest="from_currency", required=True, help="Исходная валюта")
    rate_parser.add_argument("--to", dest="to_currency", required=True, help="Целевая валюта")
    rate_parser.set_defaults(func=get_rate_command)
    
    return parser


def main():
    parser = create_parser()
    
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)
    
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()